package com.chava.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.hardware.SensorManager;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "db";
    static final String TITLE = "Title";
    static final String VALUE = "Value";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table constants  (_id integer primary key autoincrement, title text, value text)");
        ContentValues cv = new ContentValues();
        cv.put(TITLE, "Gravity Death Star I");
        cv.put(VALUE, SensorManager.GRAVITY_DEATH_STAR_I);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Earth");
        cv.put(VALUE, SensorManager.GRAVITY_EARTH);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Jupiter");
        cv.put(VALUE, SensorManager.GRAVITY_JUPITER);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Mars");
        cv.put(VALUE, SensorManager.GRAVITY_MARS);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Sun");
        cv.put(VALUE, SensorManager.GRAVITY_SUN);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Saturn");
        cv.put(VALUE, SensorManager.GRAVITY_SATURN);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Mercury");
        cv.put(VALUE, SensorManager.GRAVITY_MERCURY);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Venus");
        cv.put(VALUE, SensorManager.GRAVITY_VENUS);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Uranus");
        cv.put(VALUE, SensorManager.GRAVITY_URANUS);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Neptune");
        cv.put(VALUE, SensorManager.GRAVITY_NEPTUNE);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity Pluto");
        cv.put(VALUE, SensorManager.GRAVITY_PLUTO);
        db.insert("constants", TITLE,cv);

        cv.put(TITLE, "Gravity The Island");
        cv.put(VALUE, SensorManager.GRAVITY_THE_ISLAND);
        db.insert("constants", TITLE,cv);
    }

    public DatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, version);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
